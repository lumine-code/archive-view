import math

samples = [math.sin(i / 4) for i in range(40)]
print(f"Generated {len(samples)} samples")
